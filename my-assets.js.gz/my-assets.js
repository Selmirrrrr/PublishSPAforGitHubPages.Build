self.assetsManifest = {
  "version": "lld8JGd4",
  "assets": [
    {
      "hash": "sha256-G8nE3nHyEnViLPoqh/04rv8vHawGLQCasRY6eSvOOGA=",
      "url": "SampleApp.styles.css"
    },
    {
      "hash": "sha256-/PbvE6qnnEDO3aL/UsN1rdRqu86udyP8e55jCA8jTgI=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ca5xgge1r2.wasm"
    },
    {
      "hash": "sha256-JmnBR4DcINen5czBo7dWB5Wil0VAtvxF2gFSwXW5Lc0=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.26c9tx9k9t.wasm"
    },
    {
      "hash": "sha256-MIQAkbwY/9gy+/CnG3UtpUeWNyRMn26RmdDEMeIz3KU=",
      "url": "_framework/Microsoft.AspNetCore.Components.wcqz4sq856.wasm"
    },
    {
      "hash": "sha256-3ADlF4CLU1Q+dQbj0MnPVnEJPiA4q4Jv5xxmiGEvBks=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.85u9862gz3.wasm"
    },
    {
      "hash": "sha256-kKMubKJ3c2lATxpoAuoDqMjzQ+a0M6Ym35pK74cMK2o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.0cm6d8ej68.wasm"
    },
    {
      "hash": "sha256-fN4AyqImDQ+h3H7tFeF4ZSkjIHJ7qWgbKL217x6P53s=",
      "url": "_framework/Microsoft.Extensions.Configuration.cyz6aj3end.wasm"
    },
    {
      "hash": "sha256-UKpLgubIOAmn/oPTHaop+Ppw0ZUyarHjxoPCCBBBQWs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.04io4cndlx.wasm"
    },
    {
      "hash": "sha256-Sgs1bgmGaF2mv6rWcaihc+x48ZQQAidfzYwZvYX5WJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.uum8fsrbn4.wasm"
    },
    {
      "hash": "sha256-aO9VtQiCfALBUiKSRliDgJ8yiO3sXSupu5+y3hxbWFo=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.os166f6kpj.wasm"
    },
    {
      "hash": "sha256-I/euMiwOKn2U2Y1vqcUjYWEG/7zWmvDiTlHAoPLRHQ0=",
      "url": "_framework/Microsoft.Extensions.Logging.p9svcbtg1a.wasm"
    },
    {
      "hash": "sha256-zb8jFz8oWzH9QDCIv6znwkEZEqBZjRrXTb7biON1h4o=",
      "url": "_framework/Microsoft.Extensions.Options.z0tlm9uxjf.wasm"
    },
    {
      "hash": "sha256-Y7+Ee2DJrdAFIYTnAKXZcv8xVEtfQjGGCP0PknJTWPQ=",
      "url": "_framework/Microsoft.Extensions.Primitives.7n6rlssyfp.wasm"
    },
    {
      "hash": "sha256-ubnFa4Rtxgu4gPe/SRKYk17LxS0CtEOnEoPvT6ITOTo=",
      "url": "_framework/Microsoft.JSInterop.7kva84rxiz.wasm"
    },
    {
      "hash": "sha256-mpyjzA6YBuV9Qx5BUC8YbXP9YjZlM+k7YTVawzXJFgk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.imfqvv3x5h.wasm"
    },
    {
      "hash": "sha256-JaUAIrkU/lSVFpyj9/I7Y5P+wrCVqHg8Ql0CdzMGxZE=",
      "url": "_framework/SampleApp.fjykbxid7m.wasm"
    },
    {
      "hash": "sha256-y61a2lc04XAiyLG7Oro76xO8JPGFbljhxHO5eLq8bj8=",
      "url": "_framework/System.Collections.Concurrent.rcsdtsjm0y.wasm"
    },
    {
      "hash": "sha256-yvXj+BY8lfn2bP3iPC4VzYYEWvO8bGtoTCqiNsfgg4A=",
      "url": "_framework/System.Collections.Immutable.6ki1ylmf7z.wasm"
    },
    {
      "hash": "sha256-oHB+ufA02AyuBsVl6ysGNCIP5WMvQx6QQiA1HZDDkoI=",
      "url": "_framework/System.Collections.k3m27vz11t.wasm"
    },
    {
      "hash": "sha256-EdstTP9IiGWSnfAiUfYQU/+yVLpIFnkDsEhkbUYb1Bk=",
      "url": "_framework/System.ComponentModel.nu6ttwym4t.wasm"
    },
    {
      "hash": "sha256-OeYtPvMXSeoK79gTKBykKKWIjeiDUDEnMa/AHbAAj/I=",
      "url": "_framework/System.Console.tvcofgaxpb.wasm"
    },
    {
      "hash": "sha256-C79zJ7hIxLVfhsEYcN7AAEtP581xjGH2kdzH8I04rNA=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.7tzbxp3lnd.wasm"
    },
    {
      "hash": "sha256-FBW6K4TORa24v2L639DPjf309NTGkrj0iIqiJaPqcYA=",
      "url": "_framework/System.IO.Pipelines.wn1erg3up3.wasm"
    },
    {
      "hash": "sha256-rlsbxCBzhK6k7badDHb8pAavP1PHes99emT7cvHDUt0=",
      "url": "_framework/System.Linq.upf7pkly5d.wasm"
    },
    {
      "hash": "sha256-RlfFVD8tmd886YxRB7kM4rQ7q6CR6pJdl7RbC+QmqlA=",
      "url": "_framework/System.Memory.y5rjb3vii6.wasm"
    },
    {
      "hash": "sha256-lg0DJekX/gRNZ0zWUC1gB68jHd/ZNp9GSvYIkz1uG+c=",
      "url": "_framework/System.Net.Http.Json.2dwvsjpgge.wasm"
    },
    {
      "hash": "sha256-WyrQfsrcShHIUf9dh84BZfH9cP9ToSQhgb8acRMBCQs=",
      "url": "_framework/System.Net.Http.l4oyjdifh0.wasm"
    },
    {
      "hash": "sha256-ugfBlS5LqkQzRBUO5HH/Axxqs3sJtDp7O2gUMNFiHIM=",
      "url": "_framework/System.Net.Primitives.i2i5lejvy5.wasm"
    },
    {
      "hash": "sha256-qvJiek4yP9PVp8bCYOWFmNF1wRocmKj9Xe4E/oAiajo=",
      "url": "_framework/System.Private.CoreLib.qn00ia5owd.wasm"
    },
    {
      "hash": "sha256-s+aSpB/zWC/yGkFhe3gO2noJbKt041m8/eT5FtfJcXo=",
      "url": "_framework/System.Private.Uri.5e97e0630b.wasm"
    },
    {
      "hash": "sha256-ROLjBG47obha5D5WnH0gmUcgmcl/VaKhCSu/8k8nupY=",
      "url": "_framework/System.Runtime.4che7n70wu.wasm"
    },
    {
      "hash": "sha256-dr2zPg+11BQOd27TZPxcs18PqUREGUfAtTD9nRdz7sw=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.it9v611w20.wasm"
    },
    {
      "hash": "sha256-+y7W1KnwkH6Qwrz33TSxWAn666Cbuzvn6QwDB/OpQgI=",
      "url": "_framework/System.Text.Encodings.Web.9rjk8as0i7.wasm"
    },
    {
      "hash": "sha256-PaUiTGEAWpmpBoNQBQG4G044wn6I9CKQKZKVBLBsY2w=",
      "url": "_framework/System.Text.Json.nfx6s832ck.wasm"
    },
    {
      "hash": "sha256-tWq9vht0rY9iM6tvHI4CaV2Nogm0sR+EJEOy72TVrIk=",
      "url": "_framework/System.Text.RegularExpressions.5gjltihx5v.wasm"
    },
    {
      "hash": "sha256-fn+FCPoKfsB/fijfAgPhWXm+fKwiHBGVNSJBECsNg3c=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-N+/jRbIsqVbSKyrJpXTfko/MbGFn4mYhGgK+pW+zQ7o=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-62UC3VfSQyaGpPUm7iSjBYuQ1xD31WdRYY20NQ1K+Vs=",
      "url": "_framework/dotnet.native.d2w7colv7e.wasm"
    },
    {
      "hash": "sha256-ddUN4+taa/Qv7Mr8mLpunJO+0Xw3ViOqBvedhe57/hA=",
      "url": "_framework/dotnet.native.l4ptthxatg.js"
    },
    {
      "hash": "sha256-yfXUv1l/B489E8p12JxUvxly0JvHL9CCsoZUDlfGH9c=",
      "url": "_framework/dotnet.runtime.drv0pr9n5o.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-c4tZCDbu0JnldbnisjREzeU9Z8Gi6tWw+QJjcviGzwk=",
      "url": "index.html"
    },
    {
      "hash": "sha256-7IQ+pBT+HcjaBGLKdUm8otrsGLglsKQqwOdSTrmAqBo=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
